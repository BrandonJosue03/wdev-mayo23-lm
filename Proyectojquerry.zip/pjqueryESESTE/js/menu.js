$("#menuprincipal").html(`<div class="col-md-3 mb-2 mb-md-0">
<a href="/" class="d-inline-flex link-body-emphasis text-decoration-none">
  <svg class="bi" width="40" height="32" role="img" aria-label="Bootstrap"><use xlink:href="#bootstrap"/></svg>
</a>
</div>

<ul class="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
<li><a href="index.html" class="nav-link px-2 link-primary">Home</a></li>
<li><a href=" https://paginas-web-cr.com/ApiPHP/" class="nav-link px-2">API</a></li>
<li><a href="crearcurso.html" class="nav-link px-2">Crear Curso</a></li>
<li><a href="listarcurso.html" class="nav-link px-2">Listar curso</a></li>
</ul>`);







// // menuprincipal.innerHTML += `<div class="col-md-3 mb-2 mb-md-0">
// // <a href="/" class="d-inline-flex link-body-emphasis text-decoration-none">
// //   <svg class="bi" width="40" height="32" role="img" aria-label="Bootstrap"><use xlink:href="#bootstrap"/></svg>
// // </a>
// // </div>

// // <ul class="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
// // <li><a href="index.html" class="nav-link px-2 link-primary">Home</a></li>
// // <li><a href=" https://paginas-web-cr.com/ApiPHP/" class="nav-link px-2">API</a></li>
// // <li><a href="crearcurso.html" class="nav-link px-2">Crear Curso</a></li>
// // <li><a href="listarcurso.html" class="nav-link px-2">Listar curso</a></li>
// // </ul>`;


